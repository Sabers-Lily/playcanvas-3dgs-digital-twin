import fs from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { app, BrowserWindow, dialog } from 'electron';
import { getDesktopPaths } from './paths.js';
import { startApiProcess, stopApiProcess } from './apiProcess.js';

let mainWindow = null;
let apiRuntime = null;
const preloadPath = fileURLToPath(new URL('./preload.js', import.meta.url));

function createWindow(preloadPath) {
  const window = new BrowserWindow({
    width: 1600,
    height: 960,
    minWidth: 1280,
    minHeight: 720,
    backgroundColor: '#101826',
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: preloadPath
    }
  });

  window.on('closed', () => {
    if (mainWindow === window) {
      mainWindow = null;
    }
  });

  return window;
}

async function bootstrapDesktopApp() {
  const desktopPaths = getDesktopPaths(app);

  if (!fs.existsSync(desktopPaths.webIndexPath)) {
    throw new Error(`Web build not found: ${desktopPaths.webIndexPath}`);
  }

  if (!fs.existsSync(desktopPaths.apiServerEntry)) {
    throw new Error(`API entry not found: ${desktopPaths.apiServerEntry}`);
  }

  if (!apiRuntime || apiRuntime.childProcess?.exitCode !== null) {
    apiRuntime = await startApiProcess({
      serverEntry: desktopPaths.apiServerEntry,
      appDataDir: desktopPaths.appDataDir,
      logsDir: desktopPaths.logsDir,
      ffmpegPath: desktopPaths.ffmpegPath
    });
  }

  mainWindow = createWindow(preloadPath);

  const webUrl = new URL(pathToFileURL(desktopPaths.webIndexPath).href);
  webUrl.searchParams.set('apiBase', apiRuntime.apiBaseUrl);
  await mainWindow.loadURL(webUrl.href);
}

app.whenReady().then(async () => {
  try {
    await bootstrapDesktopApp();
  } catch (error) {
    console.error('[DesktopApp] startup failed:', error);
    await dialog.showMessageBox({
      type: 'error',
      title: '桌面版启动失败',
      message: error?.message || 'Unknown startup error'
    });
    app.quit();
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', async () => {
  await stopApiProcess(apiRuntime);
});

app.on('activate', async () => {
  if (!mainWindow) {
    await bootstrapDesktopApp();
  }
});
